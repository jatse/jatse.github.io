package tse.jason.cst338final;

import android.content.Context;
import android.os.Handler;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import java.util.Random;

public class Meteor
{

    private int meteorSpeed;
    public int meteorHP;
    public ImageView image;
    public boolean isLive = true;
    private Random random = new Random();
    private Handler handler;

    /*
    Spawn meteor
     */
    public Meteor(final ImageView thePlayer)
    {
        //Get access to UI Thread
        Context gameContext = thePlayer.getContext();
        handler = new Handler(gameContext.getMainLooper());
        image = new ImageView(gameContext);

        //randomize meteor size and speed
        switch(random.nextInt(3))
        {
            case 0 :
                image.setImageResource(R.drawable.meteor1);
                meteorHP = 1;
                break;
            case 1 :
                image.setImageResource(R.drawable.meteor2);
                meteorHP = 2;
                break;
            case 2 :
                image.setImageResource(R.drawable.meteor3);
                meteorHP = 3;
                break;
        }
        meteorSpeed = random.nextInt(50) + 1; //speed between 1 and 50

        //Post to UI thread for rendering
        handler.post(new Runnable()
        {
            @Override
            public void run()
            {
                RelativeLayout theGameArea = (RelativeLayout) thePlayer.getParent();
                theGameArea.addView(image);
                image.setX(random.nextInt(theGameArea.getWidth() - 80));
                image.setY(-image.getHeight());
                image.setRotation(random.nextInt(360));
            }
        });
    }

    /*
    Moves meteor based on its speed and player's score
     */
    public void animate(final int score)
    {
        handler.post(new Runnable()
        {
            @Override
            public void run()
            {
                image.setY(image.getY() + meteorSpeed + (score / 4));
                image.setRotation(image.getRotation() + (meteorSpeed/4));
                //if meteor is beyond screen or not live; remove.
                RelativeLayout theGameArea = (RelativeLayout) image.getParent();
                if(image.getY() > theGameArea.getHeight() || !isLive || meteorHP <= 0)
                {
                    isLive = false;
                    theGameArea.removeView(image);
                }
            }
        });
    }

}
