package tse.jason.cst338final;

import android.os.Handler;
import android.widget.ImageView;
import android.widget.RelativeLayout;

public class Laser extends Thread
{
    private static final int LASER_SPEED = 60;
    public ImageView image;
    public boolean isLive = true;
    private boolean onScreen = true; //for collisions
    private Handler handler = new Handler();
    private int fps;

    /*
    Spawn laser
     */
    public Laser(ImageView thePlayer, RelativeLayout theGameArea, int fps)
    {
        //set refresh rate
        this.fps = fps;

        //get location of player
        float playerX = thePlayer.getX();
        float playerY = thePlayer.getY();
        int playerWidth = thePlayer.getWidth();
        int playerHeight = thePlayer.getHeight();

        //spawn laser about player
        image = new ImageView(thePlayer.getContext());
        image.setImageResource(R.drawable.laser);
        theGameArea.addView(image);
        image.setX(playerX + ((playerWidth / 2) - 7));
        image.setY(playerY - (playerHeight - 40));
    }

    /*
    Animate laser and end when leave screen
     */
    public void run()
    {
        while(isLive || onScreen)
        {
            //IMPORTANT: Run threaded UI changes using handler
            //to prevent blocking UI Thread
            handler.post(new Runnable()
            {
                @Override
                public void run()
                {
                    image.setY(image.getY() - LASER_SPEED);
                }
            });

            try
            {
                Thread.sleep(1000 / fps);
            }
            catch (InterruptedException e)
            {
                e.printStackTrace();
            }

            //destroy laser if off screen or not live
            if((image.getY() <= 0 || !isLive) && onScreen)
            {
                isLive = false;
                handler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        RelativeLayout theGameArea = (RelativeLayout) image.getParent();
                        theGameArea.removeView(image);
                        onScreen = false;
                    }
                });
            }
        }
    }
}
