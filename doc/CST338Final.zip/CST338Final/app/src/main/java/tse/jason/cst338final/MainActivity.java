package tse.jason.cst338final;

import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;


public class MainActivity extends Activity {
    /*************************
     * PHASE 1: SETUP LAYOUT *
     *************************/
    final int FRAMES_PER_SECOND = 20;
    ImageView thePlayer;
    RelativeLayout theGameArea;
    TextView playerStatusArea;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //bind game images to local variables
        thePlayer = findViewById(R.id.playerShip);
        theGameArea = findViewById(R.id.gamePlayArea);
        playerStatusArea = findViewById(R.id.playerStatus);
    }


    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideControls();
        }
    }

    /*
    Hides the default controls at the bottom of the screen.
    Referenced from: https://developer.android.com/training/system-ui/immersive
    */
    private void hideControls() {
        View controlView = getWindow().getDecorView();
        controlView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        // Stop the view from resizing
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        // Hide the controls
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    /*
    Temporarily shows the default controls at the bottom of the screen.
    Referenced from: https://developer.android.com/training/system-ui/immersive
    */
    private void showControls() {
        View controlView = getWindow().getDecorView();
        controlView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        try
        {
            Thread.sleep(1000);
            hideControls();
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
    }

    /**********************************
     * PHASE 2: SETUP PLAYER CONTROLS *
     **********************************/
    final int PLAYER_MOVEMENT_SPEED = 40; //Higher is faster
    final int MAX_LASERS = 3;
    Laser[] lasers = new Laser[MAX_LASERS];
    int gameWidth, playerWidth;
    float playerX;

    /*
    Moves the player left or right within the game area.
     */
    public void movePlayer(View view)
    {
        //Get dimensions. Cannot retrieve from onCreate;
        //objects have not been laid out and will return 0 or null
        gameWidth = theGameArea.getWidth();
        playerX = thePlayer.getX();
        playerWidth = thePlayer.getWidth();

        switch(view.getId())
        {
            case R.id.moveRightButton :
                if((playerX + playerWidth) <= gameWidth)
                {
                    playerX += PLAYER_MOVEMENT_SPEED;
                    findViewById(R.id.playerShip).setX(playerX);
                }
                break;
            case R.id.moveLeftButton :
                if(playerX >= 0)
                {
                    playerX -= PLAYER_MOVEMENT_SPEED;
                    findViewById(R.id.playerShip).setX(playerX);
                }
                break;
        }
    }

    /*
    Spawns lasers up to the maximum defined.
     */
    public void fireLaser(View view)
    {
        for(int i = 0; i < MAX_LASERS; i ++)
        {
            //Spawn laser if available slot
            if(lasers[i] == null || !lasers[i].isLive)
            {
                lasers[i] = new Laser(thePlayer, theGameArea, FRAMES_PER_SECOND);
                lasers[i].start();
                return;
            }
        }
    }

    /********************************************
     * PHASE 3: CREATE OBSTACLES AND GAME LOGIC *
     ********************************************/
    /*
    Start the spawning of obstacles (meteors).
    Monitors collisions between obstacles and
    other game objects.
    */
    public void startGame(View view)
    {
        //Remove game start button
        ImageButton startButton = findViewById(R.id.startButton);
        theGameArea.removeView(startButton);

        //start game
        Game game = new Game(thePlayer, theGameArea, playerStatusArea, lasers, FRAMES_PER_SECOND);
        game.start();
    }

}