package tse.jason.cst338final;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.os.Handler;
import java.util.Random;

public class Game extends Thread
{
    private ImageView thePlayer;
    private RelativeLayout theGameArea;
    private TextView playerStatusArea;
    private int fps;
    private boolean gameOver = false;
    public static final int MAX_METEORS = 10;
    public static Meteor[] meteors = new Meteor[MAX_METEORS];
    private int frameCount, targetFrameCount;
    private Random random = new Random();
    private int playerScore = 0, playerLives = 3;
    private Handler handler;
    private Laser[] lasers;


    public Game(ImageView thePlayer, RelativeLayout theGameArea,
                TextView playerStatusArea, Laser[] lasers, int fps)
    {
        this.thePlayer = thePlayer;
        this.theGameArea = theGameArea;
        this.playerStatusArea = playerStatusArea;
        this.lasers = lasers;
        this.fps = fps;
        frameCount = 0;
        targetFrameCount = 0;
        handler = new Handler(theGameArea.getContext().getMainLooper());
    }

    public void run()
    {
        while(!gameOver)
        {
            //Spawns meteor after target frame count is reached
            if(frameCount >= targetFrameCount)
            {
                //Spawn if space in meteor array
                for(int i = 0; i < MAX_METEORS; i ++)
                {
                    //Spawn laser if available slot
                    if(meteors[i] == null || !meteors[i].isLive)
                    {
                        meteors[i] = new Meteor(thePlayer);
                        break;
                    }
                }
                //Set next spawn event in 1-3 seconds. Faster with higher score.
                frameCount = 0;
                targetFrameCount = (fps * (random.nextInt(3) + 1)) - (playerScore/2);
            }

            //for each meteor ...
            for(int i = 0; i < MAX_METEORS; i ++)
            {
                //... if meteor is active and not null ...
                if(meteors[i] != null && meteors[i].isLive)
                {
                    //... kill if collide with ship ...
                    if(isCollide(meteors[i].image, thePlayer))
                    {
                        reduceLives();
                        meteors[i].isLive = false;
                    }

                    //... kill laser and decrement meteor HP if collide ...
                    for(int k = 0; k < lasers.length; k ++)
                    {
                        //check if laser is live
                        if(lasers[k] != null && lasers[k].isLive)
                        {
                            if(isCollide(meteors[i].image, lasers[k].image))
                            {
                                meteors[i].meteorHP -= 1;
                                scoreUpdate(1);
                                lasers[k].isLive = false;
                            }
                        }
                    }

                    //...animate/update meteor.
                    meteors[i].animate(playerScore);
                }
            }
            //check game over
            if(playerLives <= 0)
            {
                gameOver = true;
            }

            //Prepare for next frame
            frameCount ++;
            try
            {
                Thread.sleep(1000 / fps);
            }
            catch (InterruptedException e)
            {
                e.printStackTrace();
            }
        }

        //Clear meteors and show game over
        for(int i = 0; i < MAX_METEORS; i ++)
        {
            if(meteors[i] != null && meteors[i].isLive)
            {
                meteors[i].isLive = false;
                meteors[i].animate(playerScore);
            }
        }
        handler.post(new Runnable() {
            @Override
            public void run()
            {
                ImageView gameOver = theGameArea.findViewById(R.id.gameOver);
                gameOver.setVisibility(View.VISIBLE);
            }
        });
    }

    /*
    Returns true if two images overlap.
     */
    public boolean isCollide(ImageView object1, ImageView object2)
    {
        //Get bounding box
        Rect obj1Area = new Rect(
                (int) object1.getX(),
                (int) object1.getY(),
                (int)(object1.getX() + object1.getWidth()),
                (int)(object1.getY() + object1.getHeight()));
        Rect obj2Area = new Rect(
                (int) object2.getX(),
                (int) object2.getY(),
                (int)(object2.getX() + object2.getWidth()),
                (int)(object2.getY() + object2.getHeight()));

        return obj1Area.intersect(obj2Area);
    }

    /*
    Reduce player's lives by 1 and update UI
     */
    private void reduceLives()
    {
        playerLives -= 1;

        //change UI if player lives is valid
        handler.post(new Runnable()
        {
            @Override
            public void run()
            {
                Context context = playerStatusArea.getContext();
                switch (playerLives)
                {
                    case 2:
                        Drawable life2 = context.getDrawable(R.drawable.playerhealth2);
                        playerStatusArea.setCompoundDrawablesWithIntrinsicBounds(life2, null, null, null);
                        break;
                    case 1:
                        Drawable life1 = context.getDrawable(R.drawable.playerhealth1);
                        playerStatusArea.setCompoundDrawablesWithIntrinsicBounds(life1, null, null, null);
                        break;
                    case 0:
                        Drawable life0 = context.getDrawable(R.drawable.playerhealth0);
                        playerStatusArea.setCompoundDrawablesWithIntrinsicBounds(life0, null, null, null);
                        break;
                    default:
                        break;
                }
            }
        });
    }

    /*
    Updates player's score
     */
    private void scoreUpdate(int scoreChange)
    {
        playerScore += scoreChange;

        handler.post(new Runnable()
        {
            @Override
            public void run()
            {
                playerStatusArea.setText(Integer.toString(playerScore));
            }
        });

    }
}
